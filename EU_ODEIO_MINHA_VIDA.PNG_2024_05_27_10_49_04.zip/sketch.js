//tamanho
let xbolineaDeGorfe = 300;
let ybolineaDeGorfe = 200;
let tamanhoDoMeuBago = 21;
let raio = tamanhoDoMeuBago / 2;

//velocidade
let katchau = 6;
let vruumm = 6;

//tamanho da raquete
let xbaquete = 1;
let ybaquete = 150;
let wbaquete = 10;
let hbaquete = 100;

//baruio
let raquetada;
let ponto;
let trilha;

//tamanho da raquete oponente
let xraquete = 588;
let yraquete = 150;
let wraquete = 10;
let hraquete = 100;
let zuuuum;

//placarimplacavel
let meuspintos = 0;
let seupinto = 0;

function preload(){
  trilha = loadSound("epicsaxguy.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3")
}


function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
 mostraAsBolas();
desceSobeEmpinaRebola();
  realOUfake();
 raquete();
  raqueterival();
  sobeEdesceManeiro();
   onzeDeSetembro();
  vaiVai();
  chamaOvar();
  amogus();
 }



function mostraAsBolas (){
   circle(xbolineaDeGorfe,ybolineaDeGorfe,tamanhoDoMeuBago);
}

function desceSobeEmpinaRebola (){
    xbolineaDeGorfe += katchau
   ybolineaDeGorfe += vruumm
}

function realOUfake(){
  if (xbolineaDeGorfe  + raio >  width  || xbolineaDeGorfe  - raio < 0){
   katchau *= -1;
 }

 if (ybolineaDeGorfe + raio >  height || ybolineaDeGorfe - raio < 0){
   vruumm *= -1;
 }
}


function raquete() {
   rect( xbaquete, ybaquete , wbaquete , hbaquete)
}

function raqueterival() {
   rect( xraquete, yraquete , wraquete , hraquete)
}


function sobeEdesceManeiro(){
  if (keyIsDown(UP_ARROW)){
   ybaquete -= 10; 
  }
  
  if (keyIsDown(DOWN_ARROW)){
  ybaquete += 10;
  }
}

function onzeDeSetembro () {
  if (xbolineaDeGorfe -  raio < xbaquete + wbaquete && ybolineaDeGorfe - raio < ybaquete + hbaquete && ybolineaDeGorfe + raio > ybaquete ){
      katchau *= -1;
    raquetada.play();
  }
  
  if (xbolineaDeGorfe +  raio > xraquete + wraquete && ybolineaDeGorfe + raio < yraquete + hraquete && ybolineaDeGorfe - raio > yraquete ){
      katchau *= -1;
    raquetada.play();
  }
}

function vaiVai(){
  if (keyIsDown("87")){
   yraquete -= 10; 
  }
  
  if (keyIsDown(83)){
  yraquete += 10;
  }
}

function chamaOvar(){
  stroke (255)
  textAlign (CENTER)
  textSize (20)
  fill (color(255, 140, 0));
  rect (258, 5, 40, 20);
  fill (255)
  text (meuspintos, 278, 21);
  fill (color(255, 140, 0));
  rect (326, 5, 40, 20);
  fill (255)
  text (seupinto, 346, 21)
}

function amogus(){
  if (xbolineaDeGorfe > 590){
    meuspintos += 1
     ponto.play();
  }
  if (xbolineaDeGorfe < 7){
    seupinto += 1
     ponto.play();
  }
 
}


















